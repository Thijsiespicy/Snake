import pygame
import random 
import asyncio

pygame.init()

screen = pygame.display.set_mode((600, 600))
pygame.display.set_caption("Snake")

bg = pygame.image.load("Assets/BG.png").convert_alpha()
snekf = pygame.image.load("Assets/snekf.png").convert_alpha()
snekb = pygame.image.load("Assets/snekb.png").convert_alpha()
appl = pygame.image.load("Assets/apple.png").convert_alpha()

global size
global number_sheet 
global spacingx
global spacingy
global numbers
global columns

number_sheet = pygame.image.load("Assets/numbersheet.png").convert_alpha()

numbers = []

columns = []

for x in range(number_sheet.get_width()):
    visible = False

    for y in range(number_sheet.get_height()):
        if number_sheet.get_at((x, y)).a > 0:
            visible = True
            break
    columns.append(visible)

start = None

for x, visible in enumerate(columns + [False]):
    if visible and start is None:
        start = x
    elif not visible and start is not None:
        rect = pygame.Rect(start, 0, x - start, number_sheet.get_height())
        numbers.append(number_sheet.subsurface(rect).copy())
        start = None




def draw_score(size, x, y):
    size_text = str(size)

    for digit in size_text:
        image = numbers[int(digit)]

        screen.blit(image, (x, y))

        x += image.get_width() + 5
    
    
async def menu ():
    pygame.display.set_caption("Menu")
    screen.blit(bg, (0,0))
    MenuText = pygame.transform.scale((pygame.image.load("Assets/logo.png").convert_alpha()), (313*1.5,57*1.5))
    Menurectangle = MenuText.get_rect(center=(300, 100))
    running = True
    play_image=pygame.image.load("Assets/playbutton.png").convert_alpha()
    play_image_hover=play_image.copy()
    play_image_hover.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_MULT)



    
    play_rect=play_image.get_rect(center=(300,400))
    
    clock = pygame.time.Clock()

    while running:
        Mousepos = pygame.mouse.get_pos()

        screen.blit(bg, (0,0))

        screen.blit(MenuText, Menurectangle)

        if play_rect.collidepoint(Mousepos):
            screen.blit(play_image_hover, play_rect)
        else:
            screen.blit(play_image, play_rect)
        
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
           
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if play_rect.collidepoint(event.pos):
                        pygame.display.set_caption("Snake")
                        await play()
                        return
                    
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)


async def play ():
    
    running = True
    snekpos = [(120,300), (60, 300), (0, 300)]
    new_head = snekpos[0]
    clock = pygame.time.Clock()
    tickspeed = 500
    direction = "right"
    currentdirection = "right"
    newdirection = "right"
    last = pygame.time.get_ticks()
    apple = "yes"
    applex = random.randint(0,9)*60
    appley = random.randint(0,9)*60 
    while (applex, appley) in snekpos:
        applex = random.randint(0,9)*60
        appley = random.randint(0,9)*60 
    global size 
    size = 3
    while running:

        #rendering snake
        screen.fill((46, 16, 16))
        for body in snekpos[1:]:
            screen.blit(snekb, body)
        head = snekpos[0]
        if newdirection == "up":
            screen.blit(pygame.transform.rotate(snekf, 180), head)
        if newdirection == "down":
            screen.blit(snekf, head)
        if newdirection == "right":
            screen.blit(pygame.transform.rotate(snekf, 90), head)
        if newdirection == "left":
            screen.blit(pygame.transform.rotate(snekf, 270), head)

        #inputs
        if (pygame.key.get_pressed() [pygame.K_UP] or pygame.key.get_pressed() [pygame.K_w]) and currentdirection != "down":
            direction = "up"
        if (pygame.key.get_pressed() [pygame.K_DOWN] or pygame.key.get_pressed() [pygame.K_s]) and currentdirection != "up":
            direction = "down"
        if (pygame.key.get_pressed() [pygame.K_LEFT] or pygame.key.get_pressed() [pygame.K_a]) and currentdirection != "right":
            direction = "left"
        if (pygame.key.get_pressed() [pygame.K_RIGHT] or pygame.key.get_pressed() [pygame.K_d]) and currentdirection != "left":
            direction = "right"

        #rendering apple, and making you be able to collect it
        screen.blit(pygame.transform.scale(appl, (40, 40)), (applex + 10, appley + 10))    

        if (applex, appley) == new_head:
                size += 1 
                apple = "no"

        if apple == "no":
            while (applex, appley) in snekpos:
                applex = random.randint(0,9)*60
                appley = random.randint(0,9)*60 
            apple = "yes"


        
        #tickspeed zone
        now = pygame.time.get_ticks()
        if now - last > tickspeed: 

            #movement
            head_x, head_y = snekpos[0]

            if direction == "up":
                head_y -= 60
            elif direction == "down":
                head_y += 60
            elif direction == "left":
                head_x -= 60
            elif direction == "right":
                head_x += 60
            newdirection = direction
            new_head = (head_x, head_y)

            #making player not grow when no apple
            if not (applex, appley) == new_head:
                snekpos.pop()
            #dying 
            if new_head in snekpos:
                pygame.display.set_caption("You died")
                await death()
            snekpos.insert(0, new_head)

            last = now
            currentdirection = direction
            new_head = snekpos[0]

            if head_x < 0 or head_x > 540 or head_y < 0 or head_y > 540:
                pygame.display.set_caption("You died")
                await death()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        pygame.display.flip()

        clock.tick(60)
        await asyncio.sleep(0)
    pygame.quit()

async def death ():
    running = True
    clock = pygame.time.Clock()
    screen.blit(bg, (0,0))

    size_text = pygame.image.load("Assets/size.png").convert_alpha()
    you_died_message = pygame.transform.scale((pygame.image.load("Assets/youdied.png").convert_alpha()),(457*1.2, 57*1.2))
    again_image = pygame.image.load("Assets/againbutton.png").convert_alpha()
    again_image_hover = again_image.copy()
    again_image_hover.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_MULT)
    menu_image = pygame.image.load("Assets/menubutton.png").convert_alpha()
    menu_image_hover = menu_image.copy()
    menu_image_hover.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_MULT)

    size_rect=size_text.get_rect(center=(300, 200))
    again_rect=again_image.get_rect(center=(300, 500))
    menu_rect=menu_image.get_rect(center=(300, 400))
    you_died_rect=you_died_message.get_rect(center=(300, 100))
    screen.blit(you_died_message, you_died_rect)
    
    while running:
            screen.blit(size_text, size_rect)

            Mousepos=pygame.mouse.get_pos()

            if menu_rect.collidepoint(Mousepos):
                screen.blit(menu_image_hover, menu_rect)
            else:
                screen.blit(menu_image, menu_rect)
     
            if again_rect.collidepoint(Mousepos):
                screen.blit(again_image_hover, again_rect)
            else:
                screen.blit(again_image, again_rect)



            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if again_rect.collidepoint(event.pos):
                            await play()          
                            return

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        if menu_rect.collidepoint(event.pos):
                            await menu()
                            return
                        
            draw_score(size, 448, 170)
            
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    pygame.quit()
        


if __name__ =="__main__":
    asyncio.run(menu())